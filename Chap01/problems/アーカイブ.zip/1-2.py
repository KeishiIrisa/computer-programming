x = input()

print(x)
