x = input()

print(x + "?")
